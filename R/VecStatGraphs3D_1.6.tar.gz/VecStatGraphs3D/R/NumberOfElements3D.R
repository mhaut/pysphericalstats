NumberOfElements3D <- function (modules) 
{
    return(length(modules))
}
