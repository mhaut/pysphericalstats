ModuleSum3D <- function (modules) 
{
    return(sum(modules))
}
