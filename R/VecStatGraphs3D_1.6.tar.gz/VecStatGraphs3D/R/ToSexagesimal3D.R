ToSexagesimal3D <- function (radians) 
{
    grades = 180 * radians/pi
    return(grades)
}
