Pause <-
function () { 
    cat("Hit <enter> to continue...")
    readline()
    invisible()
}

