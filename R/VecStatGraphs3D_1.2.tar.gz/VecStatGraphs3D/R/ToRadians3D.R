ToRadians3D <-
function(grades){
  radians=(grades/180*pi);
  return(radians);
}

