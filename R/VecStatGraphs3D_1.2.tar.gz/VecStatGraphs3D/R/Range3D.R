Range3D <-
function(modules){
   return(abs(MaxValue3D(modules)-MinValue3D(modules)));
}

