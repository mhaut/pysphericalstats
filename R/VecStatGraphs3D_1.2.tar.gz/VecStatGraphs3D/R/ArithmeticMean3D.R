ArithmeticMean3D <-
function(modules){
  return(ModuleSum3D(modules)/NumberOfElements3D(modules));
}

