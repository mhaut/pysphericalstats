MinValue3D <-
function(modules){
  return(min(modules));
}

