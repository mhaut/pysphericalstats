MaxValue3D <-
function(modules){
  return(max(modules));
}

